#ifndef __CUSTOMER_H__
#define __CUSTOMER_H__

extern const int product_control(void);

#endif
