#ifndef _LINUX_STDIO_H_
#define _LINUX_STDIO_H_

#ifdef __cplusplus
extern "C" {
#endif

extern int sscanf(char *buf, char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif /* _LINUX_STDIO_H_ */
