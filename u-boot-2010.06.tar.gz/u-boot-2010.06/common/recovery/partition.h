#ifndef _PARTITION_H_
#define _PARTITION_H_

#define PTN_MAX_NAME_LEN 20
#define PTN_MAX_ENTRY_NUM 32

typedef struct _ptn_info
{
    unsigned long data_start;
    unsigned long data_len;
    int datatype;
} s_ptn_info;

typedef struct _ptn_entry
{
    char name[PTN_MAX_NAME_LEN];
    unsigned long base;
    unsigned long tail;
    unsigned long size;
    unsigned long used_size;
    s_ptn_info data_info;
} s_ptn_entry;

typedef struct _ptn_tbl
{
    s_ptn_entry entries[PTN_MAX_ENTRY_NUM];
} s_ptn_tbl;

extern int get_partition(const char *ptn_name, unsigned long len, void* buf);

#endif
