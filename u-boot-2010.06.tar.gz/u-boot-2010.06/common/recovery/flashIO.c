#include <common.h>
#include <spi_flash.h>

#include <asm/io.h>
#include "flashIO.h"

#ifndef CONFIG_SF_DEFAULT_BUS
# define CONFIG_SF_DEFAULT_BUS 0
#endif
#ifndef CONFIG_SF_DEFAULT_CS
# define CONFIG_SF_DEFAULT_CS 0
#endif
#ifndef CONFIG_SF_DEFAULT_SPEED
# define CONFIG_SF_DEFAULT_SPEED 1000000
#endif
#ifndef CONFIG_SF_DEFAULT_MODE
# define CONFIG_SF_DEFAULT_MODE SPI_MODE_3
#endif

static struct spi_flash *flash;

int flash_probe(void)
{
    unsigned int bus = CONFIG_SF_DEFAULT_BUS;
    unsigned int cs = CONFIG_SF_DEFAULT_CS;
    unsigned int speed = CONFIG_SF_DEFAULT_SPEED;
    unsigned int mode = CONFIG_SF_DEFAULT_MODE;
    struct spi_flash *new = NULL;

    new = spi_flash_probe(bus, cs, speed, mode);
    if (!new) {
        printf("Failed to initialize SPI flash at %u:%u\n", bus, cs);
        return 1;
    }

    if (flash) {
        spi_flash_free(flash);
    }
    
    flash = new;

    return 0;
}

int flash_erase(unsigned long addr, unsigned long len)
{
    int ret = 1;
    ret = spi_flash_erase(flash, addr, len);
    if (ret) {
        printf("flash erase failed\n");
        return 1;
    }

    return 0;
}

int flash_read(unsigned long addr, unsigned long len, unsigned long buf_addr)
{
    void *buf = NULL;
    int ret = 1;
    
    buf = map_physmem((unsigned long)buf_addr, len, MAP_WRBACK);
    if (!buf) {
        puts("Failed to map physical memory\n");
        return 1;
    }

    ret = spi_flash_read(flash, addr, len, buf);
    unmap_physmem(buf, len);

    if (ret) {
        printf("flash read failed\n");
        return 1;
    }

    return 0;
}

int flash_write(unsigned long addr, unsigned long len, unsigned long buf_addr)
{
    void *buf = NULL;
    int ret = 1;

    buf = map_physmem((unsigned long)buf_addr, len, MAP_WRBACK);
    if (!buf) {
        puts("Failed to map physical memory\n");
        return 1;
    }

    ret = spi_flash_write(flash, addr, len, buf);
    unmap_physmem(buf, len);

    if (ret) {
        printf("flash write failed\n");
        return 1;
    }

    return 0;
}
