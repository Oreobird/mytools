#include <common.h>
#include <malloc.h>

#include "partition.h"

static s_ptn_tbl* ptn_name_to_entry(s_ptn_tbl *ptn_tbl, const char *name)
{
    int i = 0;

    if (ptn_tbl == NULL || name == NULL) {
        printf("ptn_name_to_entry input error\n");
        return NULL;
    }

    for (i = 0; i < PTN_MAX_NUM; i++) {
        if (strcmp(name, ptn_tbl->entries[i].name) == 0) {
            return &(ptn_tbl->entries[i]);
        }
    }

    return NULL;
}

static void read_ptn_tbl(void)
{
    int index;
}

int get_partition(const char *ptn_name, unsigned long len, void *buf)
{
    
}


//get_kernel()
//get_rootfs()
//get_sp_fs()
//get_md5()
//check_md5()
//
