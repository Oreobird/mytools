#ifndef _FLASH_IO_H_
#define _FLASH_IO_H_

extern int flash_probe(void);
extern int flash_erase(unsigned long addr, unsigned long len); 
extern int flash_read(unsigned long addr, unsigned long len, unsigned long buf_addr);
extern int flash_write(unsigned long addr, unsigned long len, unsigned long buf_addr);

#endif
